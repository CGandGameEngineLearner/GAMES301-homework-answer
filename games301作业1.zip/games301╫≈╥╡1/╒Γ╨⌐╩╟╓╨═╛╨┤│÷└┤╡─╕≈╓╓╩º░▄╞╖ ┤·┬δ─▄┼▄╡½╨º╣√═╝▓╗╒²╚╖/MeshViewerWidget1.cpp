#include <QtCore>
#include "MeshViewerWidget.h"
#include <Eigen\Eigen>


MeshViewerWidget::MeshViewerWidget(QWidget* parent)
	: QGLViewerWidget(parent),
	ptMin(0,0,0),
	ptMax(0,0,0),
	isEnableLighting(true),
	isTwoSideLighting(false),
	isDrawBoundingBox(false),
	isDrawBoundary(false)
{
}

MeshViewerWidget::~MeshViewerWidget(void)
{
}

bool MeshViewerWidget::LoadMesh(const std::string & filename)
{
	Clear();

	bool read_OK = acamcad::polymesh::loadMesh(filename, polyMesh);
	std::cout << "Load mesh from file " << filename << std::endl;
	if (read_OK)
	{
		strMeshFileName = QString::fromStdString(filename);
		QFileInfo fi(strMeshFileName);
		strMeshPath = fi.path();
		strMeshBaseName = fi.baseName();
		UpdateMesh();
		update();
		return true;
	}
	return false;
}

void MeshViewerWidget::Clear(void)
{
	polyMesh->clear();
}

void MeshViewerWidget::UpdateMesh(void)
{
	polyMesh->updateFacesNormal();
	polyMesh->updateMeshNormal();
	polyMesh->updateVerticesNormal();
	if (polyMesh->numVertices() == 0)
	{
		std::cerr << "ERROR: UpdateMesh() No vertices!" << std::endl;
		return;
	}
	ptMin[0] = ptMin[1] = ptMin[2] = DBL_MAX;
	ptMax[0] = ptMax[1] = ptMax[2] = -DBL_MAX;

	for (const auto& vh : polyMesh->vertices())
	{
		auto p = vh->position();
		for (size_t i = 0; i < 3; i++)
		{
			ptMin[i] = ptMin[i] < p[i] ? ptMin[i] : p[i];
			ptMax[i] = ptMax[i] > p[i] ? ptMax[i] : p[i];
		}
	}

	double avelen = 0.0;
	double maxlen = 0.0;
	double minlen = DBL_MAX;
	for (const auto& eh : polyMesh->edges()) {
		double len = eh->length();
		maxlen = len > maxlen ? len : maxlen;
		minlen = len < minlen ? len : minlen;
		avelen += len;
	}

	SetScenePosition((ptMin + ptMax)*0.5, (ptMin - ptMax).norm()*0.5);
	std::cout << "Information of the input mesh:" << std::endl;
	std::cout << "  [V, E, F] = [" << polyMesh->numVertices()<< ", " << polyMesh->numEdges() << ", " << polyMesh->numPolygons() << "]\n";
	std::cout << "  BoundingBox:\n";
	std::cout << "  X: [" << ptMin[0] << ", " << ptMax[0] << "]\n";
	std::cout << "  Y: [" << ptMin[1] << ", " << ptMax[1] << "]\n";
	std::cout << "  Z: [" << ptMin[2] << ", " << ptMax[2] << "]\n";
	std::cout << "  Diag length of BBox: " << (ptMax - ptMin).norm() << std::endl;
	std::cout << "  Edge Length: [" << minlen << ", " << maxlen << "]; AVG: " << avelen / polyMesh->numEdges() << std::endl;
}

bool MeshViewerWidget::SaveMesh(const std::string & filename)
{
	return acamcad::polymesh::writeMesh(filename, polyMesh);
}

bool MeshViewerWidget::ScreenShot()
{
	update();
	QString filename = strMeshPath + "/" + QDateTime::currentDateTime().toString("yyyyMMddHHmmsszzz") + QString(".png");
	QImage image = grabFramebuffer();
	image.save(filename);
	std::cout << "Save screen shot to " << filename.toStdString() << std::endl;
	return true;
}

void MeshViewerWidget::SetDrawBoundingBox(bool b)
{
	isDrawBoundingBox = b;
	update();
}
void MeshViewerWidget::SetDrawBoundary(bool b)
{
	isDrawBoundary = b;
	update();
}
void MeshViewerWidget::EnableLighting(bool b)
{
	isEnableLighting = b;
	update();
}
void MeshViewerWidget::EnableDoubleSide(bool b)
{
	isTwoSideLighting = b;
	update();
}

void MeshViewerWidget::ResetView(void)
{
	ResetModelviewMatrix();
	ViewCenter();
	update();
}

void MeshViewerWidget::ViewCenter(void)
{
	if (polyMesh->numVertices()!=0)
	{
		UpdateMesh();
	}
	update();
}

void MeshViewerWidget::CopyRotation(void)
{
	CopyModelViewMatrix();
}

void MeshViewerWidget::LoadRotation(void)
{
	LoadCopyModelViewMatrix();
	update();
}

void MeshViewerWidget::PrintMeshInfo(void)
{
	std::cout << "Mesh Info:\n";
	std::cout << "  [V, E, F] = [" << polyMesh->numVertices() << ", " << polyMesh->numEdges() << ", " << polyMesh->numPolygons() << "]\n";
	std::cout << "  BoundingBox:\n";
	std::cout << "  X: [" << ptMin[0] << ", " << ptMax[0] << "]\n";
	std::cout << "  Y: [" << ptMin[1] << ", " << ptMax[1] << "]\n";
	std::cout << "  Z: [" << ptMin[2] << ", " << ptMax[2] << "]\n";
	std::cout << "  Diag length of BBox: " << (ptMax - ptMin).norm() << std::endl;
	
}

void MeshViewerWidget::DrawScene(void)
{
	glMatrixMode(GL_PROJECTION);
	glLoadMatrixd(&projectionmatrix[0]);
	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixd(&modelviewmatrix[0]);
	//DrawAxis();
	if (isDrawBoundingBox) DrawBoundingBox();
	if (isDrawBoundary) DrawBoundary();
	if (isEnableLighting) glEnable(GL_LIGHTING);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, isTwoSideLighting);
	DrawSceneMesh();
	if (isEnableLighting) glDisable(GL_LIGHTING);
}

void MeshViewerWidget::DrawSceneMesh(void)
{
	if (polyMesh->numVertices() == 0) { return; }
	SetMaterial();
	switch (drawmode)
	{
	case POINTS:
		DrawPoints();
		break;
	case WIREFRAME:
		DrawWireframe();
		break;
	case HIDDENLINES:
		DrawHiddenLines();
		break;
	case FLATLINES:
		DrawFlatLines();
		break;
	case FLAT:
		glColor3d(0.8, 0.8, 0.8);
		DrawFlat();
		break;
	default:
		break;
	}
}

void MeshViewerWidget::DrawPoints(void) const
{
	glColor3d(1.0, 0.5, 0.5);
	glPointSize(5);
	glBegin(GL_POINTS);
	for (const auto& vh : polyMesh->vertices()) {
		glNormal3dv(vh->normal().data());
		glVertex3dv(vh->position().data());
	}
	glEnd();
}

void MeshViewerWidget::DrawWireframe(void) const
{
	glColor3d(0.2, 0.2, 0.2);
	glBegin(GL_LINES);
	for (const auto& eh : polyMesh->edges()) {
		auto heh = eh->halfEdge();
		auto v0 = heh->fromVertex();
		auto v1 = heh->toVertex();
		glNormal3dv(v0->normal().data());
		glVertex3dv(v0->position().data());
		glNormal3dv(v1->normal().data());
		glVertex3dv(v1->position().data());
	}
	glEnd();
}

void MeshViewerWidget::DrawHiddenLines() const
{
	glLineWidth(1.0);
	float backcolor[4];
	glGetFloatv(GL_COLOR_CLEAR_VALUE, backcolor);
	glColor4fv(backcolor);
	glDepthRange(0.01, 1.0);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	if (glIsEnabled(GL_LIGHTING))
	{
		glDisable(GL_LIGHTING);
		DrawFlat();
		glEnable(GL_LIGHTING);
	}
	else
	{
		DrawFlat();
	}
	glDepthRange(0.0, 1.0);
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glColor3d(.3, .3, .3);
	DrawFlat();
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
}

void MeshViewerWidget::DrawFlatLines(void) const
{
	glEnable(GL_POLYGON_OFFSET_FILL);
	glPolygonOffset(1.5f, 2.0f);
	glShadeModel(GL_FLAT);
	//glColor3d(0.8, 0.8, 0.8);
	glColor3d(1.0, 1.0, 1.0);
	DrawFlat();
	glDisable(GL_POLYGON_OFFSET_FILL);
	if (glIsEnabled(GL_LIGHTING))
	{
		glDisable(GL_LIGHTING);
		DrawWireframe();
		glEnable(GL_LIGHTING);
	}
	else
	{
		DrawWireframe();
	}
}

void MeshViewerWidget::DrawFlat(void) const
{
	glBegin(GL_TRIANGLES);
	for (const auto& fh : polyMesh->polyfaces())
	{
		glNormal3dv(fh->normal().data());
		for (const auto& fvh :polyMesh->polygonVertices(fh))
		{
			glVertex3dv(fvh->position().data());
		}
	}
	glEnd();
}


void MeshViewerWidget::DrawBoundingBox(void) const
{
	float linewidth;
	glGetFloatv(GL_LINE_WIDTH, &linewidth);
	glLineWidth(2.0f);
	glColor3d(.3, .7, .3);
	glBegin(GL_LINES);
	for (const auto& i : { 0, 1 })
	{
		for (const auto& j : { 0, 1 })
		{
			for (const auto& k : { 0, 1 })
			{
				glVertex3d(i ? ptMin[0] : ptMax[0], j ? ptMin[1] : ptMax[1], k ? ptMin[2] : ptMax[2]);
				glVertex3d(~i ? ptMin[0] : ptMax[0], j ? ptMin[1] : ptMax[1], k ? ptMin[2] : ptMax[2]);
				glVertex3d(i ? ptMin[0] : ptMax[0], j ? ptMin[1] : ptMax[1], k ? ptMin[2] : ptMax[2]);
				glVertex3d(i ? ptMin[0] : ptMax[0], ~j ? ptMin[1] : ptMax[1], k ? ptMin[2] : ptMax[2]);
				glVertex3d(i ? ptMin[0] : ptMax[0], j ? ptMin[1] : ptMax[1], k ? ptMin[2] : ptMax[2]);
				glVertex3d(i ? ptMin[0] : ptMax[0], j ? ptMin[1] : ptMax[1], ~k ? ptMin[2] : ptMax[2]);
			}
		}
	}
	glEnd();
	glLineWidth(linewidth);
}

double det(Eigen::Vector3d a, Eigen::Vector3d b)
{
	return a.x() * b.y() - b.x() * a.y();
}

void MeshViewerWidget::DrawBoundary(void) const
{
	float linewidth;
	glGetFloatv(GL_LINE_WIDTH, &linewidth);
	glLineWidth(2.0f);
	glColor3d(0.1, 0.1, 0.1);
	glBegin(GL_LINES);
	
	size_t n_vertices = polyMesh->numVertices();
	int n_boundary_vertexs = 0;//�������Ե������������

	///*********************************************
	//�����Ƹ�����,������Ե�����ж��ٸ�
	for (const auto& eh : polyMesh->edges())
	{
		if (polyMesh->isBoundary(eh))
		{
			n_boundary_vertexs++;
		}
	}
	//**********************************************

	
	//�����Ե������ȷֲ���͹����α�Ե�������
	std::vector<acamcad::MPoint3> positons_of_boundary_points;

	double rad_step = 2 * M_PI / n_boundary_vertexs;
	for (int i = 0; i < n_boundary_vertexs; i++)
	{
		double rad = i * rad_step;
		double x = std::cos(rad);
		double y = std::sin(rad);
		double z = 0;
		positons_of_boundary_points.push_back(acamcad::MPoint3(x, y, z));
	}
	//************************************************

	
	//Ѱ��������ı�Ե����
	auto half_edge = polyMesh->edges().at(0)->halfEdge();
	for (const auto& eh : polyMesh->edges())
	{
		if (polyMesh->isBoundary(eh))
		{
			half_edge= eh->halfEdge();
			break;
		}
	}
	//*************************************************


	//*************************************************
	//�ѱ�Ե������ȷֲ���͹�������
	for (size_t i=0;i<n_boundary_vertexs;i++) 
	{
		
		half_edge->toVertex()->setPosition(positons_of_boundary_points.at(i));
		
		if (half_edge->next()->isBoundary())
		{
			
			half_edge = half_edge->next();
			
		}
		else
		{
			half_edge = half_edge->pair();
			
		}
	}
	//**************************************************

	
	std::vector<Eigen::Triplet<double>> triplet_list;

	//�����Ⱥ��ұߵľ���B
	Eigen::VectorXd Bu = Eigen::VectorXd::Zero(n_vertices);
	Eigen::VectorXd Bv = Eigen::VectorXd::Zero(n_vertices);
	
	for (auto vertex = polyMesh->vertices_begin(); vertex != polyMesh->vertices_end(); vertex++)
	{
		double n_neibors = 0.0;//�ھӶ��������
		int vertex_index = (*vertex)->index();
		if (polyMesh->isBoundary(*vertex))
		{
			triplet_list.push_back(Eigen::Triplet<double>(vertex_index, vertex_index,1));
			auto postion = (*vertex)->position();
			Bu(vertex_index) = (*vertex)->position().x();
			Bv(vertex_index) = (*vertex)->position().y();
		}
		else
		{
			std::vector<acamcad::polymesh::VertexVertexIter> neibors;
			for (auto iterator = polyMesh->vv_iter(*vertex); iterator.isValid(); ++iterator)
			{
				neibors.push_back(iterator);
				n_neibors += 1.0;
				//triplet_list.push_back(Eigen::Triplet<double>(vertex_index, (*iterator)->index(),1));
			}


			double theta = 0;//����Ƕ�֮��
			std::vector<double> ang_x;
			ang_x.push_back(acamcad::vectorAngle((*neibors.at(neibors.size()-1))->position() - (*vertex)->position(), (*neibors.at(0))->position() - (*vertex)->position()));
			for (size_t k = 1; k < neibors.size(); k++)
			{
				double ang = acamcad::vectorAngle((*neibors.at(k - 1))->position()-(*vertex)->position(), (*neibors.at(k))->position() - (*vertex)->position());
				ang_x.push_back(ang);
				theta += ang;
			}

			std::vector<double> phi;//���Ƕȱ������䵽
			for (size_t i = 0; i < ang_x.size(); i++)
			{
				phi.push_back(2 * M_PI * ang_x.at(i) / theta);
			}

			std::vector<acamcad::MPoint3>P;
			double P1_x = ((*neibors.at(0))->position() - (*vertex)->position()).norm();
			P.push_back(acamcad::MPoint3(P1_x, 0, 0));

			double Pk_1_ang = 0;//������ʾ��PΪԭ�㣬PP[1]ΪX�᷽��ļ�����ϵ�£�P[k+1]��ķ�λ��
			std::vector<double> P_k_dis;//ÿ�����򶥵������Ķ���ľ���
			std::vector<double> P_k_ang;//ÿ�����򶥵�ķ�λ��
			std::vector<acamcad::MPoint3> P_k_pos;//ÿ�����򶥵��ֱ������ϵ����
			P_k_dis.push_back(((*neibors.at(0))->position() - (*vertex)->position()).norm());
			P_k_ang.push_back(0);
			P_k_pos.push_back(acamcad::MPoint3(((*neibors.at(0))->position() - (*vertex)->position()).norm(), 0, 0));
			for (size_t i = 1; i < phi.size(); i++)
			{
				Pk_1_ang += phi.at(i);
				double Pk_1_dis = ((*neibors.at(i))->position() - (*vertex)->position()).norm();//������ϵ�еľ���
				double x = Pk_1_dis * std::cos(Pk_1_ang);
				double y = Pk_1_dis * std::sin(Pk_1_ang);
				double z = 0;
				P.push_back(acamcad::MPoint3(x, y, z));
				P_k_dis.push_back(((*neibors.at(i))->position() - (*vertex)->position()).norm());
				P_k_ang.push_back(Pk_1_ang);
				P_k_pos.push_back(acamcad::MPoint3(x,y,z));
			}


			Eigen::MatrixXd Mu= Eigen::MatrixXd::Zero(neibors.size(),neibors.size());
			for (size_t l = 0; l < neibors.size(); l++)
			{
				double P_l_ang = 0;
				//if (P_k_ang.at(l) <= M_PI)
				//{
				//	P_l_ang = P_k_ang.at(l) + M_PI;
				//}
				//else
				//{
				//	P_l_ang = P_k_ang.at(l) - M_PI;
				//}
				//printf("%zu %zu %zu\n",neibors.size(), P_k_ang.size(), P_k_pos.size());
				
				for (size_t k = 1;k < neibors.size();k++)
				{
					//AΪP[l]���㣬BΪP[r]���㣬CΪP[r+1]����
					auto P = acamcad::MPoint3(0, 0, 0);
					auto A = P_k_pos.at(l);
					auto B = P_k_pos.at(k - 1);
					auto C = P_k_pos.at(k);

					Eigen::Vector3d a(A.x(), A.y(), A.z());
					Eigen::Vector3d b(B.x(), B.y(), B.z());
					Eigen::Vector3d c(C.x(), C.y(), C.z());

					
					//if (P_l_ang >= P_k_ang.at(k - 1) && P_l_ang < P_k_ang.at(k)&&k!=l&&k-1!=l)//����ֱ��PP[l]�ཻ��P[r]P[r+1]��
					if(a.cross(b).dot(a.cross(c))<=0&&k-1!=l&&k!=l)
					{	
						//auto BC = B - C;
						//auto BP = P - B;
						
						//auto CA = A - C;
						//auto CP = P - C;

						//auto AB = B - A;
						//auto AP = P - A;
						
						//auto n = AB.cross(C - A);
						//auto na = BC.cross(BP);;
						//auto nb = CA.cross(CP);
						//auto nc = AB.cross(AP);

						
						//Mu(l, l) =abs( (n.dot(na)) / n.dot(n));
						//Mu(l, k - 1) =abs( (n.dot(nb)) / n.dot(n));
						//Mu(l, k) = 1- Mu(l, l)- Mu(l, k - 1);
						
						double w_bc = abs(det(b,c) )/ 2;
						double w_ca = abs(det(c, a)) / 2;
						double w_ab = abs(det(a, b)) / 2;

						double sum_w = w_bc + w_ca + w_ab;
						Mu(l, l) = w_bc / sum_w;
						Mu(l, k - 1)= w_ca / sum_w;
						Mu(l, k) = 1- Mu(l, l)- Mu(l, k - 1);

						printf("A:%lf %lf %lf\n", A.x(), A.y(), A.z());
						printf("B:%lf %lf %lf\n", B.x(), B.y(), B.z());
						printf("C:%lf %lf %lf\n", C.x(), C.y(), C.z());

						//printf("n:%lf %lf %lf\n",n.x(),n.y(),n.z());
						//printf("na:%lf %lf %lf\n", na.x(), na.y(), na.z());
						//printf("nb:%lf %lf %lf\n", nb.x(), nb.y(), nb.z());
						//printf("nc:%lf %lf %lf\n", nc.x(), nc.y(), nc.z());
						printf("%lf %lf %lf\n", P_l_ang, P_k_ang.at(k - 1), P_k_ang.at(k));
						printf("%lf %lf %lf\n", Mu(l, l), Mu(l, k - 1), Mu(l, k));
						printf("\n");
						break;
					}
				}
			}
			
			Eigen::VectorXd Sum_mu = Mu.rowwise().sum();
			

			size_t size = neibors.size();
			double sum_weight = 0;
			for (size_t n = 0; n< size; n++)
			{
				double sum_mu = Sum_mu[n];
				double Wij = sum_mu / n_neibors;
				sum_weight += Wij;
				Eigen::Triplet<double> t((*vertex)->index(), (*neibors.at(n))->index(), Wij);
				triplet_list.push_back(t);
			}
			printf("%lf", sum_weight);
			Eigen::Triplet<double> t((*vertex)->index(), (*vertex)->index(), -sum_weight);
			triplet_list.push_back(t);
		}
	}
	//**********************************************************************************
	
	//�����Ⱥ���ߵľ���A
	Eigen::SparseMatrix<double> A(n_vertices, n_vertices);
	A.setFromTriplets(triplet_list.begin(), triplet_list.end());

	
	std::cout << A.sum();
	Eigen::SparseLU<Eigen::SparseMatrix<double>>solver;
	solver.compute(A);
	//******************************************************
	
	//�����Է�����Ax=B
	Eigen::VectorXd Xu = solver.solve(Bu);
	Eigen::VectorXd Xv = solver.solve(Bv);
	Eigen::MatrixX2d Xuv;
	Xuv.resize(n_vertices, 2);
	Xuv.col(0) = Xu;
	Xuv.col(1) = Xv;
	//**************************************

	//������������������
	for (size_t i = 0; i < n_vertices; i++)
	{
		polyMesh->vert(i)->setPosition(Xuv(i, 0), Xuv(i, 1), 0);
	}
	//*****************************************************

	glEnd();
	glLineWidth(linewidth);
}

